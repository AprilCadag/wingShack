package com.example.wingshack.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.wingshack.R;

public class FoodDetailActivity extends AppCompatActivity {

    private int itemCount = 1; // Initial item count

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewholder_fooddetail);

        ImageView imageView = findViewById(R.id.itemImage);
        TextView itemName = findViewById(R.id.itemName);
        TextView itemPrice = findViewById(R.id.itemPrice);
        TextView details = findViewById(R.id.details);

        // Retrieve data from intent extras
        Intent intent = getIntent();
        int imageResId = intent.getIntExtra("imageResId", R.drawable.chicken);
        String name = intent.getStringExtra("name");
        String price = intent.getStringExtra("price");
        String detailsText = intent.getStringExtra("details");

        // Set data to views
        imageView.setImageResource(imageResId);
        itemName.setText(name);
        itemPrice.setText(price);
        details.setText(detailsText);

        // Plus button click listener
        Button plusButton = findViewById(R.id.plusButton);
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemCount++; // Increment item count
                updateItemCount(); // Update the displayed item count
            }
        });

        // Minus button click listener
        Button minusButton = findViewById(R.id.minusButton);
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemCount > 1) {
                    itemCount--; // Decrement item count if greater than 1
                    updateItemCount(); // Update the displayed item count
                }
            }
        });

        // Add to cart button click listener
        Button addToCartButton = findViewById(R.id.addToCartButton);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add the selected item to the cart
                // Implement your logic here
                // For example, you can display a toast message indicating that the item has been added to the cart
                Toast.makeText(FoodDetailActivity.this, "Item added to cart", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to update the displayed item count
    private void updateItemCount() {
        TextView itemCountTextView = findViewById(R.id.itemCountTextView);
        itemCountTextView.setText(String.valueOf(itemCount)); // Update the text with the current item count
    }
}
