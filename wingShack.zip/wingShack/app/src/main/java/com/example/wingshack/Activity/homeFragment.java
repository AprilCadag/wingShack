package com.example.wingshack.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wingshack.Adapter.CategoryAdapter;
import com.example.wingshack.Adapter.allAdapter;
import com.example.wingshack.Domain.AllItemDomain;
import com.example.wingshack.Domain.CategoryDomain;
import com.example.wingshack.Domain.GridSpacingItemDecoration;
import com.example.wingshack.R;

import java.util.ArrayList;

public class homeFragment extends Fragment {

    private RecyclerView.Adapter categoryAdapter;
    private RecyclerView recyclerViewCategory;
    private allAdapter allItemAdapter;
    private RecyclerView recyclerViewAllItems;
    private SearchView searchView;
    private ArrayList<AllItemDomain> allItemList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize views
        recyclerViewCategory = view.findViewById(R.id.view1);
        recyclerViewAllItems = view.findViewById(R.id.view2);
        searchView = view.findViewById(R.id.searchView);
        TextView hi = view.findViewById(R.id.hi);

        // Get intent and set the greeting text
        Intent intent = getActivity().getIntent();
        if (intent != null) {
            String Name = intent.getStringExtra("Name");
            if (Name != null) {
                hi.setText(Name + "!");
            }
        }

        // Setup RecyclerViews and populate data
        setupRecyclerViews();
        populateCategoryRecyclerView();
        populateAllItemsRecyclerView();
        setupSearchView();

        return view;
    }

    private void setupRecyclerViews() {
        // Setup Category RecyclerView
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerViewCategory.setLayoutManager(linearLayoutManager);

        // Setup All Items RecyclerView with GridLayoutManager and item decoration
        int spanCount = 3;
        int spacing = 3;
        boolean includeEdge = true;
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), spanCount);
        recyclerViewAllItems.setLayoutManager(gridLayoutManager);
        recyclerViewAllItems.addItemDecoration(new GridSpacingItemDecoration(spanCount, spacing, includeEdge));
    }

    private void populateCategoryRecyclerView() {
        ArrayList<CategoryDomain> categoryList = new ArrayList<>();
        categoryList.add(new CategoryDomain("Spicy Salted Egg Chicken", "chicken", ""));
        categoryList.add(new CategoryDomain("Quarter Pounder", "burger", ""));
        categoryList.add(new CategoryDomain("Basil Parmigiana", "chicken", ""));
        categoryList.add(new CategoryDomain("Java Chip", "drink", ""));

        categoryAdapter = new CategoryAdapter(categoryList);
        recyclerViewCategory.setAdapter(categoryAdapter);

        // Set click listener for category items
        ((CategoryAdapter) categoryAdapter).setOnItemClickListener(new CategoryAdapter.OnItemClickListener() {
            @Override
            public void onAddToCartClick(CategoryDomain category) {
                // Handle category item click
                Intent intent = new Intent(requireContext(), FoodDetailActivity.class);
                // Pass data as extras
                int drawableResourceId = requireContext().getResources().getIdentifier(category.getPic(), "drawable", requireContext().getPackageName());
                intent.putExtra("imageResId", drawableResourceId);
                intent.putExtra("name", category.getTitle());
                // You can add more extras if needed
                // Start the activity
                requireActivity().startActivity(intent);
            }
        });
    }

    private void populateAllItemsRecyclerView() {
        allItemList = new ArrayList<>();
        allItemList.add(new AllItemDomain("Original Flavor", "chicken", "₱120", "kuuk"));
        allItemList.add(new AllItemDomain("Basil Parmigiana", "chicken", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Hickory", "chicken", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Original Buffalo", "chicken", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Honey Sriracha", "chicken", "₱120", "fsf"));
        allItemList.add(new AllItemDomain("Chicken Poppers", "chicken", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Chicken Fingers", "chicken", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Java Chip", "drink", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Iced Milo", "drink", "₱120", "fsf"));
        allItemList.add(new AllItemDomain("Cappucino", "drink", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Single Quarter", "burger", "₱150", "fsf"));
        allItemList.add(new AllItemDomain("Double Quarter", "burger", "₱150", "fsf"));

        allItemAdapter = new allAdapter(allItemList, getContext()); // Pass the Context parameter
        recyclerViewAllItems.setAdapter(allItemAdapter);

        // Set click listener for item clicks
        allItemAdapter.setOnItemClickListener(new allAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(AllItemDomain item) {
                // Handle item click event
                Intent intent = new Intent(requireContext(), FoodDetailActivity.class);
                // Pass data as extras
                int drawableResourceId = requireContext().getResources().getIdentifier(item.getPic(), "drawable", requireContext().getPackageName());
                intent.putExtra("imageResId", drawableResourceId);
                intent.putExtra("name", item.getTitle());
                intent.putExtra("price", item.getPrice());
                // You can add more extras if needed
                // Start the activity
                requireActivity().startActivity(intent);
            }
        });
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // No action on submit
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText); // Filter list as text changes
                return true;
            }
        });

        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle search view expansion if needed
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                filter(""); // Reset filter when search view is closed
                return false;
            }
        });
    }

    private void filter(String text) {
        ArrayList<AllItemDomain> filteredList = new ArrayList<>();
        for (AllItemDomain item : allItemList) {
            if (item.getTitle().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        allItemAdapter.filterList(filteredList);
    }
}
