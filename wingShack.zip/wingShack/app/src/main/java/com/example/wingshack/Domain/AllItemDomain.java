package com.example.wingshack.Domain;

public class AllItemDomain {
    private String title;
    private String pic;
    private String price;
    private String details; // Add this field

    public AllItemDomain(String title, String pic, String price, String details) { // Update the constructor
        this.title = title;
        this.pic = pic;
        this.price = price;
        this.details = details; // Initialize the details field
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
