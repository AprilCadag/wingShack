package com.example.wingshack.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wingshack.Activity.FoodDetailActivity;
import com.example.wingshack.Domain.FoodDomain;
import com.example.wingshack.R;

import java.util.List;

public class foodAdapter extends RecyclerView.Adapter<foodAdapter.FoodViewHolder> {
    private final List<FoodDomain> foodItemList;
    private final Context context;

    public foodAdapter(List<FoodDomain> foodItemList, Context context) {
        this.foodItemList = foodItemList;
        this.context = context;
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_fooddetail, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodDomain foodItem = foodItemList.get(position);
        holder.allPic.setImageResource(foodItem.getImageResId());
        holder.allText.setText(foodItem.getName());
        holder.allPrice.setText(foodItem.getPrice());
        holder.details.setText(foodItem.getDetails()); // Set the details text

        // Set click listener for the card view
        holder.allCardviewHolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create intent to start FoodDetailActivity
                Intent intent = new Intent(context, FoodDetailActivity.class);
                // Pass data as extras
                intent.putExtra("imageResId", foodItem.getImageResId());
                intent.putExtra("name", foodItem.getName());
                intent.putExtra("price", foodItem.getPrice());
                intent.putExtra("details", foodItem.getDetails());
                // Start the activity
                context.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return foodItemList.size();
    }

    public static class FoodViewHolder extends RecyclerView.ViewHolder {
        CardView allCardviewHolder;
        ImageView allPic;
        TextView allText;
        TextView allPrice;
        TextView details;

        public FoodViewHolder(View itemView) {
            super(itemView);
            allCardviewHolder = itemView.findViewById(R.id.allCardviewHolder);
            allPic = itemView.findViewById(R.id.itemImage); // Make sure this ID matches the one in your XML layout
            allText = itemView.findViewById(R.id.itemName); // Make sure this ID matches the one in your XML layout
            allPrice = itemView.findViewById(R.id.itemPrice); // Make sure this ID matches the one in your XML layout
            details = itemView.findViewById(R.id.details);
        }
    }
}
