package com.example.wingshack.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.wingshack.Activity.FoodDetailActivity;
import com.example.wingshack.Domain.AllItemDomain;
import com.example.wingshack.R;

import java.util.ArrayList;

public class allAdapter extends RecyclerView.Adapter<allAdapter.ViewHolder> {

    private ArrayList<AllItemDomain> allItemDomains;
    private final Context context;
    private OnItemClickListener listener;

    public allAdapter(ArrayList<AllItemDomain> allItemDomains, Context context) {
        this.allItemDomains = allItemDomains;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_all, parent, false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AllItemDomain item = allItemDomains.get(position);
        holder.itemName.setText(item.getTitle());
        holder.itemPrice.setText(String.valueOf(item.getPrice()));

        String allPic = item.getPic();
        int drawableResourceId = holder.itemView.getContext().getResources().getIdentifier(allPic, "drawable", holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawableResourceId)
                .into(holder.itemPic);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return allItemDomains.size();
    }

    public void filterList(ArrayList<AllItemDomain> filteredList) {
        allItemDomains = filteredList;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(AllItemDomain item);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        ImageView itemPic;
        TextView itemPrice;
        CardView cardView; // Add reference to the CardView

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.allText);
            itemPic = itemView.findViewById(R.id.allPic);
            itemPrice = itemView.findViewById(R.id.allPrice);
            cardView = itemView.findViewById(R.id.allCardviewHolder); // Initialize the CardView reference
        }
    }
}
