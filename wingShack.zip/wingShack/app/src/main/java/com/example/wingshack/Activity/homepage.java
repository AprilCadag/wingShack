package com.example.wingshack.Activity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.wingshack.R;
import com.example.wingshack.databinding.ActivityHomepageBinding;

public class homepage extends AppCompatActivity {

    ActivityHomepageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomepageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        String username = getIntent().getStringExtra("Name");
        replaceFragment(new homeFragment());
        binding.bottomNavigation.setSelectedItemId(R.id.action_home);

        // Bottom Navigation
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.action_like) {
                replaceFragment(new likeFragment());
            } else if (item.getItemId() == R.id.action_profile) {
                replaceFragment(new profileFragment());
            } else if (item.getItemId() == R.id.action_home) {
                replaceFragment(new homeFragment());
            }
            return true;
        });
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }
}
